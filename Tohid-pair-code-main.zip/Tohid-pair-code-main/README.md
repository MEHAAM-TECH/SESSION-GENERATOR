# SESSION ID GENERATOR FOR WHATSAPP BOTS USING MEGA

**CRAFTED USING TEMPLATES OF TOHIDTECHINFO ( QR )  AND ALI MD ( PAIR )**

**BOTH PAIR CODE AND QR CODE WORKING**

**YOU CAN DEPLOY IT ON ANY CLOUD PLATFORM e.g `HEROKU` `RENDER` `KOYEB` etc.**

**⭐ THE REPO IF YOU ARE GOING TO COPY OR FORK**

`Note: Its Developed By A Student Of Programming Languages So If You Finds Any Errors , Please Submit A Pull Request With Complete Details 💝`


| [![TOHID KHAN](https://github.com/Tohidkhan6332.png?size=100)](https://github.com/Tohidkhan6322) |
| --- |
| [Tohid Khan](https://github.com/Tohidkhn6332) |



### <h4 align="">1. HEROKU</h4>
<p style="text-align: center; font-size: 1.2em;">


[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://dashboard.heroku.com/new?template=https://github.com/caseyweb/Tohid-pair-code)
<a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

