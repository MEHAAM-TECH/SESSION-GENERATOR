# SESSION ID GENERATOR FOR WHATSAPP BOTS USING MEGA

**CRAFTED USING TEMPLATES OF SUHAILTECHINFO ( QR )  AND PRABATH ( PAIR )**

**BOTH PAIR CODE AND QR CODE WORKING**

**YOU CAN DEPLOY IT ON ANY CLOUD PLATFORM e.g `HEROKU` `RENDER` `KOYEB` etc.**

**⭐ THE REPO IF YOU ARE GOING TO COPY OR FORK**

`Note: Its Developed By A Student Of Programming Languages So If You Finds Any Errors , Please Submit A Pull Request With Complete Details 💝`


| [![Qasim Ali](https://github.com/SilvaTechB.png?size=100)](https://github.com/SilvaTechB) |
| --- |
| [Silva](https://github.com/SilvaTechB) |
